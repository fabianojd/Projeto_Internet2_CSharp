 using Microsoft.AspNetCore.Mvc;
 [Route("api/[controller]")]
 [ApiController]
 public class TipoCursoController : ControllerBase
 {
    [HttpGet]
    public string Get()
    {
        return "Olá mundo";
    }
 }